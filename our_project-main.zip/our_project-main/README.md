
## Groub 26 
Groub 26 - website for desing and architecture department.

A web application for storage of desining and wrighting tools for the architecture department.

This Project was created with <b> Python(Django), SQlite3 , CSS3, JavaScript
,HTML5, PyCharm  </b>. 

Website includes 3 types of users (Admin,Worker and Customer).

## Project Setup:


1. make sure you have python on your computer (if not install python 3.8 from here [Python download](https://www.python.org/downloads/windows/))
2. Make sure Python is in path (if not follow this guide [Add python to path](https://datatofish.com/add-python-to-windows-path/))
3. Make sure pip is in path (if not follow this guide [Add pip to path](https://appuals.com/fix-pip-is-not-recognized-as-an-internal-or-external-command/))
5. Clone repository.
7. That’s it, you are all set up to run.

## Project Run:

1. open the project with pycharm idea
2. use the run button to run up the app

that's it you have our app running locallay on your machine
